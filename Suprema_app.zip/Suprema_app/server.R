library(shiny)

load("data/phi/phi_k100.RData")
load("data/theta/theta_k100.RData")
source("functions/topic_overview.R")
source("functions/prominent_docs.R")
source("functions/thresholding.R")
source("functions/related_docs.R")
source("functions/related_topics.R")
source("functions/query.R")
source("functions/top_terms.R")
source("functions/show_classes.R")

shinyServer(function(input, output) {
  
  # TOPIC OVERVIEW.
  tov <- reactive({
    if (nchar(input$class_tov) != 0) {
      topic_overview(phi, theta, class = input$class_tov, num_top_topics = 5, num_top_terms = 20)
    } else { 
        topic_overview(phi, theta, class = NULL, num_top_topics = 5, num_top_terms = 20)
      }
  })
  
  # PROMINENT DOCS.
  pdocs <- reactive({
    if (nchar(input$class_pdocs) != 0) {
      if (nchar(input$Id_topic_pdocs) != 0)
        prominent_docs(theta, class = input$class_pdocs, Id_topic = input$Id_topic_pdocs, num_docs = 10)
    } else {
        if (nchar(input$Id_topic_pdocs) != 0)
          prominent_docs(theta, class = NULL, Id_topic = input$Id_topic_pdocs, num_docs = 10)
      }
  })  
  
  # THRESHOLDING.
  thresh <- reactive({
    if (input$threshold != 0)
      thresholding(theta, Id_topic = input$Id_topic_pdocs, threshold = input$threshold)
  })
  
  # RELATED DOCS.
  rdocs <- reactive({
    if (nchar(input$Id_doc) != 0)
      related_docs(theta, within_class = input$checkbox, Id_doc = input$Id_doc, method = input$select1, num_docs = 10)
  })
  
  # RELATED TOPICS.
  rtopics <- reactive({
    if (nchar(input$Id_topic_rtopics) != 0)
      related_topics(phi, Id_topic = input$Id_topic_rtopics, method = input$select2, num_topics = 5)
  })
  
  # TOP TERMS IN QUERY IN RELATED TOPICS.
  top_rtopics <- reactive({
    if (nchar(input$Id_topic_rtopics_top_terms) != 0)
      top_terms(Id_topic = input$Id_topic_rtopics_top_terms, phi, num_top_terms = 20)
  })
  
  # QUERY.
  qu <- reactive({
    if (nchar(input$q) != 0) 
      query(q = input$q, phi, theta, num_top_topics = 5)
  })
  
  # TOP TERMS IN QUERY.
  top_query <- reactive({
    if (nchar(input$Id_topic_query_top_terms) != 0) 
      top_terms(Id_topic = input$Id_topic_query_top_terms, phi, num_top_terms = 20)
  })
  
  # SHOW CLASSES.
  sclasses <- reactive({
    if (input$checkbox1)
      show_classes()
  })
  
  # **************
  # RENDER OUTPUT
  # ************** 
  
  output$topic_list              <- renderPrint({tov()})          # topic overview
  output$table_pdocs             <- renderTable({pdocs()})        # prominent docs
  output$table_thresh            <- renderTable({thresh()})       # thresholding
  output$table_rdocs             <- renderTable({rdocs()})        # related docs
  output$table_related_topics    <- renderTable({rtopics()})      # related topics
  output$table_top_terms_rtopics <- renderTable({top_rtopics()})  # top terms in rtopics
  output$table_query             <- renderTable({qu()})           # query
  output$table_top_query         <- renderTable({top_query()})    # top terms in query
  output$scl                     <- renderPrint({sclasses()})     # show classes
})  
  