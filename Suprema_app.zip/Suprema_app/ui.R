library(shiny)

shinyUI(
 
  # NAVIGATION BAR. 
  navbarPage(
    title       = strong("Suprema"),
    theme       = "bootstrap_flatly.css",
    #theme       = "bootstrap_cerulean.css",
    #theme       = "bootstrap_spacelab.css",
    #theme       = "bootstrap_united.css",
    #theme       = "bootstrap.css",
    #theme       = "bootstrap1.css",
    collapsible = TRUE,
    windowTitle = "Suprema",
    #inverse = TRUE,
  
  # TAB: HOME.
  tabPanel("Home", img(src = "logoCassazione1.png", align = "right", width = "246", height = "75"),
           h2(strong("Suprema")),
           h4("Un browser basato su modelli probabilistici per l'archivio ItalGiure della Corte Suprema di Cassazione"),
           h5("Paolo Fantini (supervisore: Pierpaolo Brutti)"),
           h6("Dottorato di Ricerca in Statistica Metodologica - XXVII ciclo"),
           h6("Dipartimento di Scienze Statistiche - Facoltà di Ingegneria Informatica, Informatica e Statistica - La Sapienza di Roma "),
           hr(),         
           p("Questa applicazione realizza una proposta di browser basato su topic models per la navigazione dell'archivio elettronico delle 
             sentenze della Cassazione."),
           p("Ad oggi essa mette a disposizione le seguenti funzionalità:", align = "justify"),
           tags$ul(
             tags$li("Panoramica:          restituisce una panoramica generale sui topic del corpus"), 
             tags$li("Sentenze importanti: cerca le sentenze più importanti per classe di materia (opzionale) e per topic"), 
             tags$li("Sentenze correlate:  cerca le sentenze correlate ad una data sentenza"),
             tags$li("Topic correlati:     cerca i topic correlati ad un dato topic"),
             tags$li("Top Terms:           mostra i termini identificativi di un topic"),
             tags$li("Query:               cerca i topic più verosimili per un dato termine")
           ),
           h4("Riferimenti"),
           tags$ul(
             tags$li("David M. Blei, Andrew Y. Ng, Michael I. Jordan, Latent Dirichlet Allocation. Journal of Machine Learning Research 3 (2003) 993-1022."),
             tags$li("Thomas L. Griffiths, Mark Steyvers, Finding scientific topics. 
                     Proceedings of the National Academy of Sciences of the United States of America. 2004; 101 (Suppl 1): 5228-5235."),
             tags$li("Limin Yao, David Mimno, Andrew McCallum, Efficient Methods for Topic Model Inference on Streaming Document Collections.
                     The 15th ACM SIGKDD Conference on Knowledge Discovery and Data Mining, pp. 937-946; 2009 IR-721.")
           ),
           hr(),
           h4("Note"),
           h6("L'applicazione presuppone il processamento del corpus attraverso il modello LDA (Latent Dirichelet Allocation). 
              È costruita per illustrare percorsi di navigazione che sfruttano la rappresentazione semplificata degli elementi del corpus, 
              come mistura di topic, fornita dal modello. Il corpus originale comprende 74.858 sentenze civili (appartenenti a 20 classi di materia                        differenti) emesse dalla Cassazione nel quinquennio 2010-2014. Il modello è stato addestrato sul 75% dei documenti tramite MALLET, 
              una suite Java che implementa un efficiente Gibbs sampling per l'approssimazione delle distribuzioni a posteriori. 
              Il numero di topic è stato fissato pari a K = 100.", align = "justify"),
           h6("Questo lavoro è il risultato di una collaborazione tra CED - Corte di Cassazione, DGSTAT - Ministero della Giustizia, 
              DSS - La Sapienza di Roma")
  ),  
  
  # TAB: ANALISI. 
  navbarMenu("Analisi",
    
    # SUBTAB: PANORAMICA.         
    tabPanel("Panoramica", img(src = "logoCassazione1.png", align = "right", width = "180", height = "55"), br(), br(), br(),
             sidebarLayout(
               sidebarPanel(strong("Panoramica"),
                 textInput("class_tov", label = h4("Inserisci un ID materia (opzionale)"), value = ""),
                 checkboxInput("checkbox1", label = "Mostra le classi di materia", value = FALSE),
                 submitButton("Invia"),
                 br(),
                 helpText("Ricerca su tutte le classi se nessuna materia selezionata")
               ), 
               mainPanel(
                 tags$style(type = 'text/css', '#topic_list {color: black;}'), 
                 wellPanel(width = 8, verbatimTextOutput("topic_list")),
                 tags$style(type = 'text/css', '#scl {color: black;}'),
                 wellPanel(width = 8, verbatimTextOutput("scl"))
               )
             )
    ),                  
             
    # SUBTAB: SENTENZE IMPORTANTI.
    tabPanel("Sentenze importanti", img(src = "logoCassazione1.png", align = "right", width = "180", height = "55"),
             sidebarLayout(
               sidebarPanel(strong("Sentenze importanti"),
                 wellPanel(
                   textInput("Id_topic_pdocs", label = h4("Inserisci un ID topic"), value = ""),
                   textInput("class_pdocs", label = h4("Inserisci un ID materia (opzionale)"), value = ""),
                   submitButton("Invia"),
                   br(),
                   helpText("Ricerca su tutto il corpus se nessuna materia selezionata")
                 ), 
                 br(),
                 wellPanel(
                   numericInput("threshold", label = h4("Inserisci un valore soglia tra 0 e 1"), value = "0"),
                   submitButton("Invia")
                 )
               ), 
               mainPanel(width = 8, 
                         tableOutput("table_pdocs"),
                         tableOutput("table_thresh")
               )
             )
    ),
  
    # SUBTAB: SENTENZE CORRELATE.
    tabPanel("Sentenze correlate", img(src = "logoCassazione1.png", align = "right", width = "180", height = "55"),
             sidebarLayout(
               sidebarPanel(strong("Sentenze correlate"),
                 textInput("Id_doc", label = h4("Inserisci un ID sentenza"), value = ""),
                 checkboxInput("checkbox", label = "Cerca dentro la classe di materia della sentenza", value = TRUE),
                 selectInput("select1", label = "Scegli il metodo", choices = list("KL divergence" = "kl_sdiv", "Log difference" = "log_diff"), selected = 1),
                 submitButton("Invia")
               ), 
               mainPanel(width = 8, tableOutput("table_rdocs"))
             )
    ),

    # SUBTAB: TOPIC CORRELATI.
    tabPanel("Topic correlati", img(src = "logoCassazione1.png", align = "right", width = "180", height = "55"),
             sidebarLayout(
               sidebarPanel(strong("Topic correlati"),
                 wellPanel(
                   textInput("Id_topic_rtopics", label = h4("Inserisci un ID topic"), value = ""),
                   selectInput("select2", label = "Scegli il metodo", choices = list("KL divergence" = "kl_sdiv", "Log difference" = "log_diff"), selected = 1),
                   submitButton("Invia")
                 ),
                 br(),
                 wellPanel(
                    textInput("Id_topic_rtopics_top_terms", label = h4("Top terms (inserisci un ID topic)"), value = ""),
                    submitButton("Invia")
                 )
               ), 
               mainPanel(width = 8, 
                       tableOutput("table_related_topics"),
                       tableOutput("table_top_terms_rtopics")
               )
             )
    )
  ),
  
  # TAB: STRUMENTI.
  navbarMenu("Strumenti",
    
    # SUBTAB: QUERY.
    tabPanel("Query", img(src = "logoCassazione1.png", align = "right", width = "180", height = "55"),
             sidebarLayout(
               sidebarPanel(strong("Query"),
                 wellPanel(
                   textInput("q", label = h4("Inserisci un termine (unigram)"), value = ""),
                   submitButton("Invia")
                 ),
                 br(),
                 wellPanel(
                   textInput("Id_topic_query_top_terms", label = h4("Top terms (inserisci un ID topic)"), value = ""),
                   submitButton("Invia")
                 )
               ),
               mainPanel(width = 8, 
                         tableOutput("table_query"),
                         tableOutput("table_top_query")
               )
             )
             
    )
  )
                      
 )  # fine navbarPage
)   # fine shinyUI
