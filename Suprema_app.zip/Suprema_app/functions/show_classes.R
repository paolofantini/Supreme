show_classes <- function() {
  load("data/classi_di_materia.RData")
  print(classi_di_materia)
}
