# ********************************************************************************************

# Questa funzione prende in input le distribuzioni theta, l'id di un documento fissato 
# e il metodo di calcolo della dissimilarità tra quest'ultimo e gli altri documenti 
# del corpus. Restituisce in output la lista dei num_docs documenti più simili 
# (in quanto a distribuzioni theta) al documento dato.
# Se within_class = TRUE, la ricerca è limitata alla classe di materia del documento fissato, 
# altrimenti viene estesa a tutto il corpus (default).   

# ********************************************************************************************

# 2016 - Paolo Fantini - Dipartimento di Scienze Statistiche - La Sapienza Università di Roma

# ********************************************************************************************

related_docs <- function(theta = NULL, within_class = FALSE, Id_doc = NULL, method = c("log_diff", "kl_sdiv"), num_docs = 10) {
  
  # Librerie richieste.
  library(data.table)
  library(seewave)  # per il calcolo della KL divergence
  
  # Quale metodo?
  method <- match.arg(method)
  
  # Solo per controllo.
  theta <- as.data.table(theta)
  
  # Vettore theta del documento fissato.
  theta_Id_doc <- subset(theta, ID == Id_doc)
  
  # Per ignorare le colonne ID e classes in theta.
  startcol <- 2
  endcol   <- dim(theta)[2] - 1
  
  # Cercare all'interno della classe di materia di Id_doc?
  if (within_class)
    theta <- subset(theta, classes == theta_Id_doc$classes)
  
  # Vettore fissato da passare ad apply().
  theta_Id_doc <- theta_Id_doc[, startcol:endcol, with = FALSE]
  
  ### CALCOLO DISSIMILARITÀ ###
  
  # Metodo 1: calcola la somma delle differenze in valore assoluto dei logaritmi rispetto al doc fissato (Id_doc).
  if (method == "log_diff") {
    log_diff <- round(apply(theta[, startcol:endcol, with = FALSE], 1,
                            function(x) sum(abs(log(as.numeric(theta_Id_doc)) - log(as.numeric(x))))), 5)
    dissimilarity <- data.table(ID_doc = theta$ID, log_diff = log_diff, class = theta$classes)
    setorder(dissimilarity, log_diff)
  }
  
  # Metodo 2: calcola la divergenza (simmetrica) di KL rispetto al doc fissato (Id_doc).
  if (method == "kl_sdiv") {
    kl_sdiv <- round(apply(theta[, startcol:endcol, with = FALSE], 1,
                           function(x) kl.dist(as.numeric(theta_Id_doc), as.numeric(x))$D), 5)
    dissimilarity <- data.table(ID_doc = theta$ID, kl_sdiv = kl_sdiv, class = theta$classes)
    setorder(dissimilarity, kl_sdiv)
  }
  
  # Output.
  dissimilarity <- head(dissimilarity, num_docs)
  names(dissimilarity)[3] <- "ID_materia" 
  dissimilarity <- dissimilarity[, c(1, 3, 2), with = F]
  
  return(dissimilarity)
}
