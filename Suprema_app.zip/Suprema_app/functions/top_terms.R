# ********************************************************************************************

# Questa funzione prende in input l'id di un topic e le distribuzioni phi, e restituisce 
# in output la lista dei top terms di quel topic.

# ********************************************************************************************

# 2016 - Paolo Fantini - Dipartimento di Scienze Statistiche - La Sapienza Università di Roma

# ********************************************************************************************

top_terms <- function(Id_topic = NULL, phi = NULL, num_top_terms = 20) {
  
  # Libreria richiesta.
  library(data.table)
  
  # Solo per controllo.
  phi <- as.data.table(phi)
  
  # Top terms (ordinati in senso decrescente per valori di phi).
  top_terms <- head(phi[order(-get(Id_topic))][, .(term = term, get(Id_topic))], num_top_terms)
  names(top_terms)[2] <- Id_topic 
  
  # Output.
  return(top_terms)
}
