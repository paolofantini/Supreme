# ********************************************************************************************

# Questa funzione prende in input il termine query q e le distribuzioni phi e theta, 
# e restituisce in output la lista dei num_top_topics che hanno generato il termine q 
# con la maggiore probabilità (i topics più verosimili).

# ********************************************************************************************

# 2016 - Paolo Fantini - Dipartimento di Scienze Statistiche - La Sapienza Università di Roma

# ********************************************************************************************

query <- function(q = NULL, phi = NULL, theta = NULL, num_top_topics = 5) {
  
  # Libreria richiesta.
  library(data.table)
  
  # Carica i dati.
  #load("C:/THESIS/Rprojects/browser/data/phi/phi_k100.RData")
  #load("C:/THESIS/Rprojects/browser/data/theta/theta_k100.RData")
  
  # Solo per controllo.
  phi   <- as.data.table(phi)
  theta <- as.data.table(theta)

  # Controlla se q è presente tra i termini in phi.
  if (q %in% phi$term) {
    
    # Ignora la prima colonna (term).
    phi_term <- subset(phi, term == q)[, 2:dim(phi)[2], with = F]   
  
    # Trova i (5) topics più verosimili.
    qq <- sort(phi_term, decreasing = TRUE)[, 1:num_top_topics, with = F]           
    
  } else 
      stop("Termine '", q, "' non trovato. Prova con un altro termine.")
  
  
  
  
  
  
  # Output.  
  return(qq)  
}
