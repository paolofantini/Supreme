# ********************************************************************************************

# Questa funzione prende in input le distribuzioni theta e la classe di materia, e restituisce 
# in output la lista dei top topics (con i relativi top terms) ordinata dal più importante al
# meno importante per quella materia.
# L'importanza di un topic è misurata dalla somma (normalizzata) dei suoi valori theta 
# su tutti i documenti della classe di appartenenza.
# Se non specificato alcun id di classe (default) la ricerca dei top topics è estesa a tutto
# il corpus. 

# ********************************************************************************************

# 2016 - Paolo Fantini - Dipartimento di Scienze Statistiche - La Sapienza Università di Roma

# ********************************************************************************************

topic_overview <- function(phi = NULL, theta = NULL, class = NULL, num_top_topics = 10, num_top_terms = 20) {
  
  # Libreria richiesta.  
  library(data.table)  

  # Attenzione: serve per colSums.  
  theta <- as.data.frame(theta)   
  
  # Se analisi per classe, seleziona soltanto i docs di class.
  if (!is.null(class))  
    theta <- subset(theta, classes == class)

  # Calcola la topic presence e seleziona i top topics.
  drops      <- c("ID", "classes")
  tp_score   <- colSums(theta[, !names(theta) %in% drops])  
  tp_score   <- tp_score/sum(tp_score)  # normalizzazione
  top_topics <- head(sort(tp_score, decreasing = T), num_top_topics)   

  # Seleziona le top phi (in accordo con i top topics).
  phi     <- as.data.table(phi)  # per controllo
  top_phi <- phi[, names(top_topics), with = FALSE] 
  top_phi <- data.table(term = phi$term, top_phi)

  # Funzione per calcolare i top terms.
  FUN <- function(x) {
    c  <- x  # solo così funziona il get() che serve a passare il nome della colonna
    tt <- top_phi[, x, with = FALSE]
    tt <- data.table(term = phi$term, tt)  
    tt <- head(tt[order(-get(c))], num_top_terms)
  }

  # Output: top terms.
  top_terms        <- lapply(names(top_phi)[-1], FUN)
  names(top_terms) <- paste0(names(top_topics), " - topic presence = ", round(top_topics, 3))

  return(top_terms)
}
