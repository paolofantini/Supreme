# ********************************************************************************************

# Questa funzione prende in input le distribuzioni theta, la classe di materia 
# e l'id del topic. Restituisce in output la lista (ordinata in base ai valori di theta) 
# dei num_docs documenti più importanti per quella materia e per quel topic (pdocs).
# Se non specificato alcun id di classe (default) la ricerca dei pdocs è estesa a tutto
# il corpus.

# ********************************************************************************************

# 2016 - Paolo Fantini - Dipartimento di Scienze Statistiche - La Sapienza Università di Roma

# ********************************************************************************************

prominent_docs <- function(theta = NULL, class = NULL, Id_topic = NULL, num_docs = 10) {
  
  # Libreria richiesta.
  library(data.table)
  
  # Solo per controllo.
  theta <- as.data.table(theta)
  
  # Se analisi per classe, seleziona soltanto i docs di class (default 0 per via di textInput in shiny).
  if (!is.null(class))
    theta <- subset(theta, classes == class)
  
  # Ordina i docs (in senso decrescente) in base al vettore (in theta) assegnato da Id_topic.  
  pdocs <- theta[order(-get(Id_topic))][, .(ID_doc = ID, get(Id_topic), class = classes)]
  
  # Output.
  pdocs <- head(pdocs, num_docs)
  names(pdocs)[2:3] <- c(Id_topic, "ID_materia")
  
  pdocs <- pdocs[, c(1, 3, 2), with = F]
  
  return(pdocs)
}
  