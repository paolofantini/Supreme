# ********************************************************************************************

# Questa funzione prende in input le distribuzioni theta, l'id topic e un valore soglia e 
# restituisce in output la lista dei documenti che presentano valori di theta 
# (per quell'id topic) superiori al valore soglia.

# ********************************************************************************************

# 2016 - Paolo Fantini - Dipartimento di Scienze Statistiche - La Sapienza Università di Roma

# ********************************************************************************************

thresholding <- function(theta = NULL, Id_topic = NULL, threshold = NULL) {
  
  # Libreria richiesta.  
  library(data.table)  
  
  # textInput in Shiny trasforma input$threshold in char. 
  #threshold <- as.numeric(threshold)
  
  # Docs con valori theta (per Id_topic) superiori alla soglia.
  docs <- subset(theta, get(Id_topic) > threshold, c(ID, classes, get(Id_topic)))
  docs <- setorderv(docs, c(Id_topic, "classes", "ID"), c(-1, 1, 1))
  names(docs)[1:2] <- c("ID_doc", "ID_materia")
  
  # Output.
  return(docs)
}
