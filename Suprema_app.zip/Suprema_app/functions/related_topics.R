# ********************************************************************************************

# Questa funzione prende in input le distribuzioni phi, l'id di un topic fissato 
# e il metodo di calcolo della dissimilarità tra quest'ultimo e gli altri topic del corpus. 
# Restituisce in output la lista dei num_topics più simili (in quanto a distribuzioni phi)
# al topic dato.

# ********************************************************************************************

# 2016 - Paolo Fantini - Dipartimento di Scienze Statistiche - La Sapienza Università di Roma

# ********************************************************************************************

related_topics <- function(phi = NULL, Id_topic = NULL, method = c("log_diff", "kl_sdiv"), num_topics = 5) {
  
  # Librerie richieste.
  library(data.table)
  library(seewave)  # per il calcolo della KL divergence
  
  # Quale metodo?
  method <- match.arg(method)
  
  # Solo per controllo.
  phi <- as.data.table(phi)
  
  # Vettore phi del topic fissato da passare ad apply().
  phi_Id_topic <- phi[, get(Id_topic)]
  
  # Per ignorare la colonna term in phi.
  startcol <- 2
  endcol   <- dim(phi)[2]
  
  ### CALCOLO DISSIMILARITÀ ###
  
  # Metodo 1: calcola la somma delle differenze in valore assoluto dei logaritmi rispetto al topic fissato (Id_topic).
  if (method == "log_diff") {
    log_diff <- round(apply(phi[, startcol:endcol, with = FALSE], 2,
                            function(x) sum(abs(log(phi_Id_topic) - log(x)))), 5)
    dissimilarity <- data.table(Id_topic = names(phi)[-1], log_diff = log_diff)
    setorder(dissimilarity, log_diff)
  }
  
  # Metodo 2: calcola la divergenza (simmetrica) di KL rispetto al topic fissato (Id_topic).
  if (method == "kl_sdiv") {
    kl_sdiv <- round(apply(phi[, startcol:endcol, with = FALSE], 2,
                           function(x) kl.dist(phi_Id_topic, x)$D), 5)
    dissimilarity <- data.table(Id_topic = names(phi)[-1], kl_sdiv = kl_sdiv)
    setorder(dissimilarity, kl_sdiv)
  }
  
  # Output.
  dissimilarity <- head(dissimilarity, num_topics)
  names(dissimilarity)[1] <- "ID_topic"
  return(dissimilarity)
}
